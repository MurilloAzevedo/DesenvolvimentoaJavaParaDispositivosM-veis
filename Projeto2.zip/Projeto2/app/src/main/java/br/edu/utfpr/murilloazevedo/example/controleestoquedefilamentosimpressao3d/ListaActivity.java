package br.edu.utfpr.murilloazevedo.example.controleestoquedefilamentosimpressao3d;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.view.ActionMode;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;
import java.util.Collections;

public class ListaActivity extends AppCompatActivity {

    private ListView listViewMaterial;
    private ArrayList<Material> filamentos = new ArrayList<>();
    MaterialAdapter materialAdapter;

    private ActionMode actionMode;

    private View viewSelecionada;

    private  int posicaoSelecionada = -1;

    public static final String ARQUIVO = "br.edu.utfpr.murilloazevedo.example.controleestoquedefilamentosimpressao3d.PREFERENCIAIS";

    public static  final String ORDENACAO_ASCENDENTE = "ORDENACAO_ASCENDENTE";

    private boolean ordenacaoAscendente = true;

    private ActionMode.Callback ActionModeCallback = new ActionMode.Callback() {
        @Override
        public boolean onCreateActionMode(ActionMode mode, Menu menu) {
            MenuInflater inflate = mode.getMenuInflater();
            inflate.inflate(R.menu.principal_item_selecionado, menu);
            return true;
        }

        @Override
        public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
            return false;
        }

        @Override
        public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
            int idMenuItem = item.getItemId();

            if (idMenuItem == R.id.menuItemEditar) {
                editarCadastro();
                mode.finish();
                return true;

            } else if (idMenuItem == R.id.menuItemExcluir) {
                excluirCadastro();
                mode.finish();
                return true;

            } else {
                return false;
            }
        }

        @Override
        public void onDestroyActionMode(ActionMode mode) {
            if (viewSelecionada != null) {
                viewSelecionada.setBackgroundColor(Color.TRANSPARENT);
            }

            actionMode = null;
            viewSelecionada = null;

            listViewMaterial.setEnabled(true);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layoutPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setTitle(getString(R.string.app_name));

        listViewMaterial = findViewById(R.id.listViewMateriais);

        listViewMaterial.setChoiceMode(ListView.CHOICE_MODE_SINGLE);

        listViewMaterial.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                if (actionMode != null){
                    return false;
                }

                posicaoSelecionada = position;
                view.setBackgroundColor(Color.LTGRAY);
                viewSelecionada = view;

                listViewMaterial.setEnabled(false);
                actionMode = startSupportActionMode(ActionModeCallback);

                return false;
            }
        });


        listViewMaterial.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Material material = (Material) listViewMaterial.getItemAtPosition(position);

                Toast.makeText(getApplicationContext(),
                        material + getString(R.string.foi_selecionado),
                        Toast.LENGTH_LONG).show();
            }
        });

        lerPreferenciaOrdenacaoAscendente();

        popularLista();
    }

    ActivityResultLauncher<Intent> launcherNovoMateiral = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {

                    if(result.getResultCode() == Activity.RESULT_OK){

                        Intent intent = result.getData();

                        Bundle bundle = intent.getExtras();

                        if (bundle != null){

                            String marca = bundle.getString(ControleActivity.MARCA);
                            String tamanho = bundle.getString(ControleActivity.TAMANHO);
                            String tipo = bundle.getString(ControleActivity.TIPO);
                            String peso = bundle.getString(ControleActivity.PESO);

                            Material material = new Material(tipo,tamanho,marca,peso);

                            filamentos.add(material);

                            ordenarLista();
                        }
                    }
                }
            });

    private void popularLista(){

        filamentos = new ArrayList<>();
        materialAdapter = new MaterialAdapter(this, filamentos);
        listViewMaterial.setAdapter(materialAdapter);
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.principal_opcoes, menu);

        return true;
    }

    @SuppressLint("ResourceAsColor")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int idMenuItem = item.getItemId();

        if (idMenuItem == R.id.menuItemAdicionar){
            ControleActivity.novoMaterial(this, launcherNovoMateiral);
            return true;
        } else if (idMenuItem == R.id.menuItemSobre) {
            SobreActivity.nova(this);
            return true;
        } else if (idMenuItem == R.id.menuItemOrdenacao){
            salvarPreferenciaOrdenacaoAscendente(!ordenacaoAscendente);
            atualizarIconeOrdenacao(item);
            ordenarLista();
            return true;

        }else {
            return super.onOptionsItemSelected(item);
        }
    }

    private void excluirCadastro(){
        filamentos.remove(posicaoSelecionada);
        materialAdapter.notifyDataSetChanged();
    }

    ActivityResultLauncher<Intent> launcherEditarMateiral = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {

                    if(result.getResultCode() == Activity.RESULT_OK){

                        Intent intent = result.getData();

                        Bundle bundle = intent.getExtras();

                        if (bundle != null){

                            String marca = bundle.getString(ControleActivity.MARCA);
                            String tamanho = bundle.getString(ControleActivity.TAMANHO);
                            String tipo = bundle.getString(ControleActivity.TIPO);
                            String peso = bundle.getString(ControleActivity.PESO);

                            Material material = filamentos.get(posicaoSelecionada);
                            material.setMarca(marca);
                            material.setTamanho(tamanho);
                            material.setTipo(tipo);
                            material.setPeso(peso);

                            posicaoSelecionada = -1;

                            ordenarLista();

                        }
                    }
                }
            });

    private void editarCadastro(){
        Material material = filamentos.get(posicaoSelecionada);
        ControleActivity.editarMaterial(this, launcherEditarMateiral, material);

    }

    private void atualizarIconeOrdenacao(MenuItem menuItemOrdenecao){

        if (ordenacaoAscendente){

            menuItemOrdenecao.setIcon(R.drawable.ic_action_ordenacao_ascendente);
        }else {
            menuItemOrdenecao.setIcon(R.drawable.ic_action_ordenacao_descendente);
        }
    }

    private void ordenarLista(){

        if(ordenacaoAscendente){
            Collections.sort(filamentos, Material.crescente);
        }else{
            Collections.sort(filamentos, Material.decrescente);
        }

        materialAdapter.notifyDataSetChanged();
    }

    private void lerPreferenciaOrdenacaoAscendente(){

        SharedPreferences shared = getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE);

        ordenacaoAscendente = shared.getBoolean(ORDENACAO_ASCENDENTE, ordenacaoAscendente);
    }

    private void salvarPreferenciaOrdenacaoAscendente(boolean novoValor){

        SharedPreferences shared = getSharedPreferences(ARQUIVO, Context.MODE_PRIVATE);

        SharedPreferences.Editor editor = shared.edit();
        editor.putBoolean(ORDENACAO_ASCENDENTE, novoValor);

        editor.commit();

        ordenacaoAscendente = novoValor;
    }
}