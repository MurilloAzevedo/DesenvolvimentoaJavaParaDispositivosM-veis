package br.edu.utfpr.murilloazevedo.example.controleestoquedefilamentosimpressao3d;

import java.util.Comparator;

public class Material {

    public static Comparator crescente = new Comparator<Material>() {
        @Override
        public int compare(Material m1, Material m2) {
            return m1.getTipo().compareToIgnoreCase(m2.getTipo());
        }
    };

    public static Comparator decrescente = new Comparator<Material>() {
        @Override
        public int compare(Material m1, Material m2) {
            return -1 * m1.getTipo().compareToIgnoreCase(m2.getTipo());
        }
    };

    private String tipo;
    private String tamanho;
    private String marca;
    private String peso;

    public Material(String tipo, String tamanho, String marca, String peso){
        setTipo(tipo);
        setTamanho(tamanho);
        setMarca(marca);
        setPeso(peso);
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getPeso() {
        return peso;
    }

    public void setPeso(String peso) {
        this.peso = peso;
    }

    public String getTamanho() {
        return tamanho;
    }

    public void setTamanho(String tamanho) {
        this.tamanho = tamanho;
    }

    public  String toString(){
        return getMarca() + " - " + getTipo() + " - " + getPeso() + "\n" + getTamanho();
    }
}
