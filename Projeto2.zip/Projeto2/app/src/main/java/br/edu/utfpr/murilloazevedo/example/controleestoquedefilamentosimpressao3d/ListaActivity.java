package br.edu.utfpr.murilloazevedo.example.controleestoquedefilamentosimpressao3d;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class ListaActivity extends AppCompatActivity {

    private ListView listViewMaterial;
    ArrayList<Material> filamentos = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_lista);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listViewMaterial = findViewById(R.id.listViewMateriais);

        listViewMaterial.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                Material material = (Material) listViewMaterial.getItemAtPosition(position);

                Toast.makeText(getApplicationContext(),
                        material + getString(R.string.foi_selecionado),
                        Toast.LENGTH_LONG).show();
            }
        });

        popularLista();
    }

    ActivityResultLauncher<Intent> launcherNovoMateiral = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            new ActivityResultCallback<ActivityResult>() {
                @Override
                public void onActivityResult(ActivityResult result) {

                    if(result.getResultCode() == Activity.RESULT_OK){

                    }
                }
            });

    private void popularLista(){
        String[] tipos = getResources().getStringArray(R.array.tipo);
        String[] marcas = getResources().getStringArray(R.array.marca);
        String[] peso = getResources().getStringArray(R.array.peso);
        String[] tamanho = getResources().getStringArray(R.array.tamanho);

        for(int cont = 0; cont < tipos.length;cont++){
            filamentos.add(new Material(tipos[cont], tamanho[cont], marcas[cont], peso[cont]));
        }

        MaterialAdapter materialAdapter = new MaterialAdapter(this, filamentos);

        listViewMaterial.setAdapter(materialAdapter);
    }

    public void sobre(View view){
        SobreActivity.nova(this);
    }

    public void novoMaterial(View view){

        ControleActivity.novoMaterial(this, launcherNovoMateiral);
    }
}