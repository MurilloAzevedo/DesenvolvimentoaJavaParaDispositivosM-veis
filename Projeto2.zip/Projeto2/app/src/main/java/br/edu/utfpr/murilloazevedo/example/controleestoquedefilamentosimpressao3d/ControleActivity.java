package br.edu.utfpr.murilloazevedo.example.controleestoquedefilamentosimpressao3d;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class ControleActivity extends AppCompatActivity {

    private EditText editTextMarca;
    private CheckBox cbMaior, cbMenor;
    private RadioGroup radioGroupTipos;
    private Spinner spinnerPesos;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_controle);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        editTextMarca = findViewById(R.id.editTextMarca);
        cbMaior = findViewById(R.id.checkBoxMaior);
        cbMenor = findViewById(R.id.checkBoxMenor);
        radioGroupTipos = findViewById(R.id.radioGroupTiposFilamentos);
        spinnerPesos = findViewById(R.id.spinnerPesos);

        popularSpinner();
    }

    public void cadastro(View view){
        String marca = editTextMarca.getText().toString();
        String tamanho = "";
        Boolean mensagem = false;

        mensagem = validacao();

        if (mensagem == false) {
            Toast.makeText(this,
                    getString(R.string.cadastro_realizado)
                            + "\n" + marca + "\n" + escolhaCheckBox()
                            + escolhaRadioGroup()
                            + escolhaPeso()
                            , Toast.LENGTH_LONG).show();
        }
    }

    public void limpar(View view){
        editTextMarca.setText(null);
        cbMaior.setChecked(false);
        cbMenor.setChecked(false);
        radioGroupTipos.clearCheck();
    }
    public boolean validacao() {
        String marca = editTextMarca.getText().toString();
        String ling = (String) spinnerPesos.getSelectedItem();

        if (marca == null || marca.trim().isEmpty()) {
            Toast.makeText(this, R.string.necessario_preencher_campo_marca, Toast.LENGTH_LONG).show();
            editTextMarca.requestFocus();
            return true;
        } else if (!cbMaior.isChecked() && !cbMenor.isChecked()) {
            Toast.makeText(this, R.string.necessario_escolher_tamanho, Toast.LENGTH_LONG).show();
            cbMaior.requestFocus();
            cbMenor.requestFocus();
            return true;
        }else if (cbMaior.isChecked() && cbMenor.isChecked()) {
            Toast.makeText(this, R.string.soh_um_tipo_de_tamanho, Toast.LENGTH_LONG).show();
            cbMaior.requestFocus();
            cbMenor.requestFocus();
            return true;
        } else if (escolhaRadioGroup().equals(getString(R.string.necessario_selecionar_tipo_filamento))) {
            Toast.makeText(this, R.string.necessario_selecionar_tipo_filamento, Toast.LENGTH_LONG).show();
            radioGroupTipos.requestFocus();
            return true;
        } else if (ling == null) {
            Toast.makeText(this, R.string.necessario_selecionar_peso_filamento, Toast.LENGTH_LONG).show();
        }
        return false;
    }
    public String escolhaCheckBox (){
        String mensagem = "";

        if (cbMaior.isChecked()){
            return mensagem = getString(R.string.filamento_maior) + "\n";
        } else{
            return mensagem = getString(R.string.filamento_menor) + "\n";
        }
    }

    public String escolhaRadioGroup(){
        String mensagem = "";
        int botaoSelecionado = radioGroupTipos.getCheckedRadioButtonId();

        if (botaoSelecionado == R.id.radioButtonTPU){
            return mensagem = getString(R.string.tpu90d) + "\n";
        } else if (botaoSelecionado == R.id.radioButtonPLA) {
            return mensagem = getString(R.string.pla) + "\n";
        } else if (botaoSelecionado == R.id.radioButtonPETG) {
            return  mensagem = getString(R.string.petg) + "\n";
        }else if (botaoSelecionado == R.id.radioButtonABS){
            return  mensagem = getString(R.string.abs) + "\n";
        } else {
            return mensagem = getString(R.string.necessario_selecionar_tipo_filamento);
        }
    }

    private void popularSpinner(){
        ArrayList<String> lista = new ArrayList<>();

        lista.add(getString(R.string._500g));
        lista.add(getString(R.string._750g));
        lista.add(getString(R.string._1kg));
        lista.add(getString(R.string._2kg));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, lista);
        spinnerPesos.setAdapter(adapter);
    }

    public String escolhaPeso(){
        String ling = (String) spinnerPesos.getSelectedItem();
        String mensagem = "";

        if (ling != null){
            return mensagem = ling + "\n";
        }
        return mensagem;
    }

    public static void novoMaterial(AppCompatActivity activity, ActivityResultLauncher<Intent> launcher){

        Intent intent = new Intent(activity, ControleActivity.class);

        launcher.launch(intent);
    }

    public void cancelar(View view){
        setResult(Activity.RESULT_CANCELED);
        finish();
    }
}