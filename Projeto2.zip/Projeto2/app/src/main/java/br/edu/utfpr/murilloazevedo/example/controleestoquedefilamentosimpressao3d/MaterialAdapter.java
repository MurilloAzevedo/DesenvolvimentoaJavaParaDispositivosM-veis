package br.edu.utfpr.murilloazevedo.example.controleestoquedefilamentosimpressao3d;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.util.List;

public class MaterialAdapter extends BaseAdapter{

    private Context context;
    private List<Material> filamentos;

    private static class MaterialHolder{
        public TextView textViewMarca;
        public TextView textViewTipo;
        public TextView textViewPeso;
        public TextView textViewCor;
    }

    public MaterialAdapter(Context context, List<Material> materiais){
        this.context = context;
        this.filamentos = materiais;

    }

    @Override
    public int getCount() {
        return filamentos.size();
    }

    @Override
    public Object getItem(int position) {
        return filamentos.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        MaterialHolder holder;

        if (view == null){

            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.lista_material, viewGroup,false);

            holder = new MaterialHolder();

            holder.textViewMarca = view.findViewById(R.id.textViewMarca);
            holder.textViewTipo = view.findViewById(R.id.textViewTipo);
            holder.textViewCor = view.findViewById(R.id.textViewTamanho);
            holder.textViewPeso = view.findViewById(R.id.textViewPeso);

            view.setTag(holder);
        } else {

            holder = (MaterialHolder) view.getTag();
        }

        holder.textViewMarca.setText(filamentos.get(i).getMarca());
        holder.textViewTipo.setText(filamentos.get(i).getTipo());
        holder.textViewPeso.setText(filamentos.get(i).getPeso());
        holder.textViewCor.setText(filamentos.get(i).getTamanho());

        return view;
    }
}
