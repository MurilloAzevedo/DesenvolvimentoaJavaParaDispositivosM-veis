package br.edu.utfpr.murilloazevedo.example.controleestoquedefilamentosimpressao3d;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ArrayAdapter;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class ControleActivity extends AppCompatActivity {

    private EditText editTextMarca;
    private CheckBox cbMaior, cbMenor;
    private RadioGroup radioGroupTipos;
    private Spinner spinnerPesos;
    public static final String MARCA = "MARCA";
    public static final String TIPO = "TIPO";
    public static final String TAMANHO = "TAMANHO";
    public static final String PESO = "PESO";
    public static final String MODO = "MODO";
    public static final int NOVO = 1;
    public static final int EDITAR = 2;

    private int modo;
    private String original;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_controle);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.layoutPrincipal), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        setTitle(getString(R.string.cadastro));

        ActionBar actionBar = getSupportActionBar();
        if(actionBar != null){
            actionBar.setDisplayHomeAsUpEnabled(true);
        }

        editTextMarca = findViewById(R.id.editTextMarca);
        cbMaior = findViewById(R.id.checkBoxMaior);
        cbMenor = findViewById(R.id.checkBoxMenor);
        radioGroupTipos = findViewById(R.id.radioGroupTiposFilamentos);
        spinnerPesos = findViewById(R.id.spinnerPesos);

        Intent intent = getIntent();
        Bundle bundle = intent.getExtras();

        if(bundle != null){

            modo = bundle.getInt(MODO, NOVO);
            if (modo == NOVO){
                setTitle(getString(R.string.novo_material));
            } else if (modo == EDITAR) {
                setTitle(getString(R.string.editar));
                original = bundle.getString(MARCA);

                editTextMarca.setText(original);
                editTextMarca.setSelection(editTextMarca.getText().length());
            }
        }

        popularSpinner();
    }

    public void cadastro(){
        String marca = editTextMarca.getText().toString();
        Boolean mensagem = false;

        mensagem = validacao();

        if (mensagem == false) {

            Intent intent = new Intent();
            intent.putExtra(MARCA, marca);
            intent.putExtra(TAMANHO, escolhaCheckBox());
            intent.putExtra(TIPO, escolhaRadioGroup());
            intent.putExtra(PESO, escolhaPeso());

            setResult(Activity.RESULT_OK, intent);
            finish();
        }
    }

    public void limpar(){
        editTextMarca.setText(null);
        cbMaior.setChecked(false);
        cbMenor.setChecked(false);
        radioGroupTipos.clearCheck();
    }
    public boolean validacao() {
        String marca = editTextMarca.getText().toString();
        String ling = (String) spinnerPesos.getSelectedItem();

        if (marca == null || marca.trim().isEmpty()) {
            Toast.makeText(this, R.string.necessario_preencher_campo_marca, Toast.LENGTH_LONG).show();
            editTextMarca.requestFocus();
            return true;
        } else if (!cbMaior.isChecked() && !cbMenor.isChecked()) {
            Toast.makeText(this, R.string.necessario_escolher_tamanho, Toast.LENGTH_LONG).show();
            cbMaior.requestFocus();
            cbMenor.requestFocus();
            return true;
        }else if (cbMaior.isChecked() && cbMenor.isChecked()) {
            Toast.makeText(this, R.string.soh_um_tipo_de_tamanho, Toast.LENGTH_LONG).show();
            cbMaior.requestFocus();
            cbMenor.requestFocus();
            return true;
        } else if (escolhaRadioGroup().equals(getString(R.string.necessario_selecionar_tipo_filamento))) {
            Toast.makeText(this, R.string.necessario_selecionar_tipo_filamento, Toast.LENGTH_LONG).show();
            radioGroupTipos.requestFocus();
            return true;
        } else if (ling == null) {
            Toast.makeText(this, R.string.necessario_selecionar_peso_filamento, Toast.LENGTH_LONG).show();
        }
        return false;
    }
    public String escolhaCheckBox (){
        String mensagem = "";

        if (cbMaior.isChecked()){
            return mensagem = getString(R.string.filamento_maior) + "\n";
        } else{
            return mensagem = getString(R.string.filamento_menor) + "\n";
        }
    }

    public String escolhaRadioGroup(){
        String mensagem = "";
        int botaoSelecionado = radioGroupTipos.getCheckedRadioButtonId();

        if (botaoSelecionado == R.id.radioButtonTPU){
            return mensagem = getString(R.string.tpu90d) + "\n";
        } else if (botaoSelecionado == R.id.radioButtonPLA) {
            return mensagem = getString(R.string.pla) + "\n";
        } else if (botaoSelecionado == R.id.radioButtonPETG) {
            return  mensagem = getString(R.string.petg) + "\n";
        }else if (botaoSelecionado == R.id.radioButtonABS){
            return  mensagem = getString(R.string.abs) + "\n";
        } else {
            return mensagem = getString(R.string.necessario_selecionar_tipo_filamento);
        }
    }

    private void popularSpinner(){
        ArrayList<String> lista = new ArrayList<>();

        lista.add(getString(R.string._500g));
        lista.add(getString(R.string._750g));
        lista.add(getString(R.string._1kg));
        lista.add(getString(R.string._2kg));

        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_1, lista);
        spinnerPesos.setAdapter(adapter);
    }

    public String escolhaPeso(){
        String ling = (String) spinnerPesos.getSelectedItem();
        String mensagem = "";

        if (ling != null){
            return mensagem = ling + "\n";
        }
        return mensagem;
    }

    public static void novoMaterial(AppCompatActivity activity, ActivityResultLauncher<Intent> launcher){

        Intent intent = new Intent(activity, ControleActivity.class);

        intent.putExtra(MODO, NOVO);

        launcher.launch(intent);
    }

    public static void editarMaterial(AppCompatActivity activity, ActivityResultLauncher<Intent> launcher, Material material){

        Intent intent = new Intent(activity, ControleActivity.class);

        intent.putExtra(MODO, NOVO);
        intent.putExtra(MARCA, material.getMarca());
        intent.putExtra(TAMANHO, material.getTamanho());
        intent.putExtra(TIPO, material.getTipo());
        intent.putExtra(PESO, material.getPeso());

        launcher.launch(intent);
    }

    public void cancelar(){
        setResult(Activity.RESULT_CANCELED);
        finish();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.filamento_opcoes, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int idMenuItem = item.getItemId();

        if (idMenuItem == R.id.menuItemSalvar){
            cadastro();
            return  true;
        } else if (idMenuItem == R.id.menuItemLimpar) {
            limpar();
            return true;
        } else if (idMenuItem == android.R.id.home) {
            cancelar();
            return true;
        }else {
            return super.onOptionsItemSelected(item);
        }
    }
}